﻿namespace BAL.DTOs;

public class ListCountriesDTO
{
    public string? Name { get; set; }
    public string? Code { get; set; }
    public string? Iso3 { get; set; }
}
